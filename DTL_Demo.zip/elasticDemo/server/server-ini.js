var elasticsearch = require('elasticsearch');
var Promise = require('bluebird');
var esParser = require('es-response-parser');
var log = console.log.bind(console);
var fs=require('fs');

var client = new elasticsearch.Client({
  host: 'localhost:9200',
  log: 'trace'
});


function readResumeDataFromCSV(){
	var data = fs.readFileSync('resume_dataset.csv');
	var dataArray = CSVToArray(data);
console.log(dataArray[0][0]);
}

function dropIndex() {
  return client.indices.delete({
    index: 'test',
  });
}

function createIndex() {
  return client.indices.create({
    index: 'test',
	body:{
		settings:{
			number_of_shards: '1',
			number_of_replicas: '1'
		},
		mappings:{
			test:{
				properties:{
					gender:{
						type: 'text',
						store: 'true'
					}
				}
			}
		}
	}
	
  });
}

function addAllToIndex(){
var data = JSON.parse(fs.readFileSync('resume_dataset.json', 'utf8'));
for(var i=0; i<data.length; i++){
	if(data[i].id >= 1000){
		client.index({
		index: 'test',
		type: 'test',
		id: ""+data[i].id,
		body: {
			body: ""+data[i].body.body,
			gender: 'm'
		}
		});
	}else{
		client.index({
		index: 'test',
		type: 'test',
		id: ""+data[i].id,
		body: {
			body: ""+data[i].body.body,
			gender: 'f'
		}
		});
	}
	}
	
}

function addToIndex1() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '1',
    body: {
      body: 'hello hello hello hello hello hello hello hello hello hello',
	  gender: 'm'
    }
  });
}

function addToIndex2() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '2',
    body: {
      body: 'hello hello hello hello hello hello hello hello hello bye',
	  gender: 'm'
    }
  });
}

function addToIndex3() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '3',
    body: {
      body: 'hello hello hello hello hello hello hello hello bye bye',
	  gender: 'm'
    }
  });
}

function addToIndex4() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '4',
    body: {
      body: 'hello hello hello hello hello hello hello bye bye bye',
	  gender: 'm'
    }
  });
}

function addToIndex5() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '5',
    body: {
      body: 'hello hello hello hello hello hello bye bye bye bye',
	  gender: 'm'
    }
  });
}

function addToIndex6() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '6',
    body: {
      body: 'hello hello hello hello hello bye bye bye bye bye',
	  gender: 'f'
    }
  });
}

function addToIndex7() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '7',
    body: {
      body: 'hello hello hello hello bye bye bye bye bye bye',
	  gender: 'f'
    }
  });
}

function addToIndex8() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '8',
    body: {
      body: 'hello hello hello bye bye bye bye bye bye bye',
	  gender: 'f'
    }
  });
}

function addToIndex9() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '9',
    body: {
      body: 'hello hello bye bye bye bye bye bye bye bye',
	  gender: 'f'
    }
  });
}

function addToIndex10() {
  return client.index({
    index: 'test',
    type: 'test',
    id: '10',
    body: {
      body: 'hello bye bye bye bye bye bye bye bye bye',
	  gender: 'f'
    }
  });
}

function search() {
  return client.search({
    index: 'test',
    q: 'hello'
  }).then(log);
}

function closeConnection() {
  client.close();
}

function waitForIndexing() {
  log('Wait for indexing ....');
  return new Promise(function(resolve) {
    setTimeout(resolve, 2000);
  });
}

function dropIndex() {
  return client.indices.delete({
    index: 'test',
  });
}

//Promise.resolve().then(createTable);


Promise.resolve()
  .then(dropIndex)
  .then(createIndex)
  .then(addAllToIndex);
/*
  .then(addToIndex1)
  .then(addToIndex2)
  .then(addToIndex3)
  .then(addToIndex4)
  .then(addToIndex5)
  .then(addToIndex6)
  .then(addToIndex7)
  .then(addToIndex8)
  .then(addToIndex9)
  .then(addToIndex10);
*/