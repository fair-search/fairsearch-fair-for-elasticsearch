function fairQuery(var k, var p, var alpha){
	var http = new XMLHttpRequest();
	var url = "localhost:9200/demo/_search";
	var jsonQuery ={"query" : {"term" : { "user" : "kimchy" }}};
	http.open("GET", url);
	xmlhttp.setRequestHeader("Content-Type", "text/html");
	http.send(JSON.stringify(jsonQuery));
}


